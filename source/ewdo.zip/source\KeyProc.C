/////////////////////////////////////////////////////////////////////////
//	Project Name 	: Input for EW Inverter  
//	Fiele Name	 	: keyProc.c
//
//  Start 			: 2008.01.08 Thursday
//
///////////////////////////////////////////////////////////////////////////
// read data format   "9:4:123:x.xxxe-x"
// write data format  "9:6:123:1.234e-3"

#define KEY_IN_VIEW_SILK	1

#if KEY_IN_VIEW_SILK
#SEPARATE
BUTTON GetKey1() // ��ũ�� ���̴� ���� 
{
	BUTTON KeySave;	
	if		(!input(KEY_STOP))	KeySave = BTN_ESC;
	else if (!input(KEY_UP)) 	KeySave = BTN_SAVE;
	else if (!input(KEY_DOWN))	KeySave = BTN_RIGHT;
	else if (!input(KEY_RIGHT)) keySave = BTN_DOWN;		
	else if (!input(KEY_ESC))	KeySave = BTN_STOP;
	else if (!input(KEY_SAVE))	KeySave = BTN_UP;	
	else if (!input(KEY_SET))	KeySave = BTN_RUN;	
	else if	(!input(KEY_RUN))	KeySave = BTN_SET; 
	else 						KeySave = BTN_NULL;

	return KeySave;
}
#else
BUTTON GetKey1() // ��ũ�� ������ �ʰ� LCD ���ἱ�� ���� ���� 
{
	BUTTON KeySave;
	
	if		(!input(KEY_STOP))	KeySave = BTN_STOP;
	else if (!input(KEY_UP)) 	KeySave = BTN_UP;
	else if (!input(KEY_DOWN))	KeySave = BTN_DOWN;
	else if (!input(KEY_RIGHT)) keySave = BTN_RIGHT;		
	else if (!input(KEY_ESC))	KeySave = BTN_ESC;
	else if (!input(KEY_SAVE))	KeySave = BTN_SAVE;	
	else if (!input(KEY_SET))	KeySave = BTN_SET;	
	else if	(!input(KEY_RUN))	KeySave = BTN_RUN; 
	else 						KeySave = BTN_NULL;
	
	if(KeySave != BTN_NULL)	delay_ms(50);
	return KeySave;
}
#endif

#SEPARATE
BUTTON GetKey( )
{
	BUTTON KeySave;	

	KeySave = GetKey1();

 	if( KeySave != BTN_NULL){
		delay_ms(20);
		KeySave = GetKey1();
	}	
	if( KeySave != BTN_NULL){
		while( GetKey1()!= BTN_NULL );
		delay_ms(10);
		ulWatchDog = ulGetNowCount_msec();
	}
	return KeySave; 
}

//                          {"01234567890123456789"}
const char str_clear_line[21] = {"                    "};
const char msgEditAddr[21] ={"[EDIT] 000:0.000e+0 "};

void clear_line( int low )
{
	strcpy(st,str_clear_line); PrintLCD(low,0,st); 
}

#define JSK		7

const char CODE_POS[9][2] ={{0,0+JSK},{0,1+JSK},{0,2+JSK},
	{0,4+JSK},{0,6+JSK},{0,7+JSK},{0,8+JSK},{0,10+JSK},{0,11+JSK}};

// read data format   "0123456789012345"
// read data format   "9:4:123:x.xxxe-x"
// write data format  "9:6:123:1.234e-3"

#SEPARATE
void CopyCode2TxMsg(int cmd)
{
	gSciTxBuf[0] = '9'; gSciTxBuf[1] = ':';
	gSciTxBuf[2] = '4'; gSciTxBuf[3] = ':';
//--- write address 
	gSciTxBuf[4] = Code[0];	gSciTxBuf[5] =Code[1];	
	gSciTxBuf[6] =Code[2]; 	gSciTxBuf[7] = ':';
//--- write data
	gSciTxBuf[8]  =Code[3]; gSciTxBuf[9]  ='.';
	gSciTxBuf[10] =Code[4]; gSciTxBuf[11] =Code[5];
	gSciTxBuf[12] =Code[6]; 
//--- exponent part
	gSciTxBuf[13] ='e'; gSciTxBuf[14] =Code[7]; 
	gSciTxBuf[15] =Code[8]; 

	if( cmd == SCI_CMD_WRITE_ROM ) gSciTxBuf[2] = '6';
	else gSciTxBuf[2] = '4';				// read data		
}

#SEPARATE
void enter_monitor_mode()
{
	machine_state = STATE_MONITOR_MODE;
	LCD_Clear();				
	lcd_x_posi = 0; lcd_y_posi=0;
}

#SEPARATE
void enter_set_mode()
{
	machine_state = STATE_SET_MODE;
	LCD_Clear();
}

#SEPARATE
void enter_edit_mode()
{
	int i;
	machine_state = STATE_EDIT_MODE;
	LCD_Clear();
	strcpy(st,msgEditAddr); PrintLCD(0,0,st); 

	for ( i = 0; i< 9;i++) Code[i] = '0';
	Code[7] = '+';

	CodeID = 0;
	Cursor(CODE_POS[CodeId][0],CODE_POS[CodeId][1],CURSOR_BLINK);					
}

#SEPARATE
void enter_trip_mode()
{
	machine_state = STATE_TRIP_MODE;
	LCD_Clear();
}

#SEPARATE
void enter_reset_mode()
{
	machine_state = STATE_RESET_MODE;
	LCD_Clear();
}

#SEPARATE
void enter_time_mode()
{
	machine_state = STATE_TIME_MODE;
	LCD_Clear();
	strcpy(st, "DATE & TIME SETTING ");
	PrintLCD(0,0,st);
	delay_ms(50);
	strcpy(st, "                    ");
}

#SEPARATE
void rec_clear_mode()
{
	machine_state = RECORD_CLEAR_MODE;
	LCD_Clear();
}

#SEPARATE
void sys_init_mode()
{
	machine_state = SYSTEM_INIT_MODE;
	LCD_Clear();
}

#SEPARATE
void enter_position_mode()
{
	machine_state = STATE_POSITION_MODE;
	LCD_Clear();
}
#SEPARATE
void monitor_converter()
{
	static unsigned long msec_count=0;
	static int disp_count=0;
 
	BUTTON KeyIn;

	KeyIn = GetKey();
	if( KeyIn == BTN_SET ){
		enter_set_mode(); return;
	}
	else if(KeyIn == BTN_RUN)
	{
		strcpy(gSciTxBuf,"9:4:905:0.000e-0");
		SendSciString( gSciTxBuf );
		delay_msec(50);
	}
	else if(KeyIn == BTN_STOP)
	{
		strcpy(gSciTxBuf,"9:4:905:1.000e-0");
		SendSciString( gSciTxBuf );
		delay_msec(50);
	}
	else if(KeyIn == BTN_UP)
	{
		strcpy(gSciTxBuf,"9:4:905:2.000e-0");
		SendSciString( gSciTxBuf );
		delay_msec(50);
	}
	else if(KeyIn == BTN_DOWN)
	{
		strcpy(gSciTxBuf,"9:4:905:3.000e-0");
		SendSciString( gSciTxBuf );
		delay_msec(50);
	}

	if( ulGetDelaymSec( msec_count) < 100 ) return;

	msec_count = ulGetNowCount_msec();

	SerialPortSetup(); delay_ms(10);	// debug	

	switch(disp_count){
	case 0 :
		lcd_y_posi = 0; lcd_x_posi = 0;
		strcpy(gSciTxBuf,"9:4:901:0.000e-0");	// STATE
		break;

	case 1 :
		lcd_y_posi = 0; lcd_x_posi = 10;
		strcpy(gSciTxBuf,"9:4:902:0.000e-0");	// FREQ (HZ)
		break;

	case 2 :
		lcd_y_posi = 2; lcd_x_posi = 0;
		strcpy(gSciTxBuf,"9:4:902:1.000e-0");	// RPM
		break;

	case 3 :
		lcd_y_posi = 2; lcd_x_posi = 10;
		strcpy(gSciTxBuf,"9:4:902:2.000e-0");	// VDC 
		break;

	case 4 :
		lcd_y_posi = 3; lcd_x_posi = 0;
		strcpy(gSciTxBuf,"9:4:902:3.000e-0");	// I
		break;

	case 5:
		lcd_y_posi = 3; lcd_x_posi = 10;
		strcpy(gSciTxBuf,"9:4:902:4.000e-0");	// I_RMS 
		break;
	}
	SendSciString( gSciTxBuf );
	delay_msec(50);
	if(disp_count >= 5 ) disp_count = 0; 
	else disp_count ++;

}

#SEPARATE
void SetMenuOpen()			// System ���� �޴�
{
	BUTTON KeyIn;

	if(Flag_Start == 0)
	{
		if(Flag_Page == 1)
		{
			strcpy(st, " - MAIN MENU -   1/2");
			PrintLCD(0,0,st);

			DisplayChar(1, 0, '1');
			strcpy(st, " EDIT CTRL DATA   ");
			PrintLCD(1,2,st);

			DisplayChar(2, 0, '2');
			strcpy(st, " ERROR RECORD VIEW");
			PrintLCD(2,2,st);

			DisplayChar(3, 0, '3');
			strcpy(st, " SYSTEM RESET     ");
			PrintLCD(3,2,st);
		}
		else if(Flag_Page == 2)
		{
			strcpy(st, " - MAIN MENU -   2/2");
			PrintLCD(0,0,st);

			DisplayChar(1, 0, '4');
			strcpy(st, " DATE & TIME SET  ");
			PrintLCD(1,2,st);

			DisplayChar(2, 0, '5');
			strcpy(st, " RECORD CLEAR ALL ");
			PrintLCD(2,2,st);

			DisplayChar(3, 0, '6');
			strcpy(st, " SYSTEM INIT      ");
			strcpy(st, " POSION VALUE TEST");
			PrintLCD(3,2,st);
		}
		Flag_Start = 1;
	}
	KeyIn = GetKey();

	switch( KeyIn )
	{
	case BTN_DOWN:
		Flag_Start = 0;
		Delay_Cnt = 99;
	//	if(Flag_Page != 2)
		Old_SetLineNum = Flag_Set;
		Flag_Set++;		// �޴� �Ʒ���
		break;
	case BTN_UP:
		Flag_Start = 0;
		Delay_Cnt = 99;
//		if(Flag_Page != 2)
		Old_SetLineNum = Flag_Set;
		Flag_Set--;		// �޴� ����
		break;
	case BTN_SET:
		Flag_Start = 0;
		Delay_Cnt = 99;
		Flag_page = 1;
		if(Flag_Set == 1)
		{
			enter_edit_mode();
			return;
		}
		else if(Flag_Set == 2)
		{
			Flag_Set = 1;
			enter_trip_mode();
			return;
		}
		else if(Flag_Set == 3)
		{
			Flag_Set = 1;
			enter_reset_mode();
			return;
		}
		else if(Flag_Set == 4)
		{
			Flag_Set = 1;
			enter_time_mode();
			return;
		}
		else if(Flag_Set == 5)
		{
			Flag_Set = 1;
			rec_clear_mode();
			return;
		}
		else if(Flag_Set == 6)
		{
			Flag_Set = 1;
		//	sys_init_mode();
			enter_position_mode();
			return;
		}
		break;
	case BTN_ESC:
		Flag_Start = 0;
		if(Flag_page == 2)
		{
			Old_SetLineNum = Flag_Set - 3;
			Flag_Set = 1;
		}
		Flag_Page = 1;
		Delay_Cnt = 99;
		break;
	case BTN_RIGHT:
		Flag_Start = 0;
		if(Flag_page == 1)
		{
			Old_SetLineNum = Flag_Set + 3;
			Flag_Set = 4;
		}
		Flag_Page = 2;
		Delay_Cnt = 99;
		break;
	case BTN_STOP:
		Delay_Cnt = 99;
		Flag_Page = 1;
		Flag_Set = 1;
		Flag_Btn = 2;
		Flag_Start = 0;
		enter_monitor_mode();
		break;
	default:
		break;
	}
	if(Flag_Page != 2)
	{
		if(Flag_Set > 3)
			Flag_Set = 1;
		else if(Flag_Set < 1)
			Flag_Set = 3;
	}
	else if(Flag_Page == 2)
	{
		if(Flag_Set > 6)
			Flag_Set = 4;
		else if(Flag_Set < 4)
			Flag_Set = 6;
	}
	st[0] = Flag_Set + '0';

	Delay_Cnt++;

	if(Delay_Cnt == 100)
		if(Flag_Set >= 4)
		{
			DisplayChar(Flag_Set - 3, 0, st[0] );
			DisplayChar(Old_SetLineNum - 3, 1, ' ');
			DisplayChar(Flag_Set - 3, 1, 126 );
		}
		else
		{
			DisplayChar(Flag_Set, 0, st[0] );
			DisplayChar(Old_SetLineNum, 1, ' ');
			DisplayChar(Flag_Set, 1, 126 );
		}
	
	if(Delay_Cnt > 200)
	{
		if(Flag_Set >= 4)
			DisplayChar(Flag_Set - 3, 0, ' ' );
		else
			DisplayChar(Flag_Set, 0, ' ' );
		Delay_Cnt = 0;
	}
}

#SEPARATE
void EditCodeDataProc()
{
	int ChangeCode =0;
	int i;
	int clearcnt;

	BUTTON KeyIn;

	KeyIn = GetKey();
	
	ChangeCode = 1;
	Cursor(CODE_POS[CodeID][0],CODE_POS[CodeID][1],DISPLAY_CURSE_BLINK_ON);//CURSOR_OFF);
	if( KeyIn == BTN_NULL )	return;	
	switch( KeyIn )
	{
	case BTN_NULL:		break;

	case BTN_ESC:
//			gMachineState = STATE_MAIN_MENU; LoopCtrl = 0; 
		if(CodeId == 0) CodeID = 8 ;
		else			CodeID -- ;	
		break;
	case BTN_SET:
		for( i = 1 ; i< 4; i++ ) clear_line(i);

		CopyCode2TxMsg(SCI_CMD_READ_DATA);

	//--- write data
		gSciTxBuf[9]  ='.';	gSciTxBuf[10] ='0'; gSciTxBuf[11] ='0';	gSciTxBuf[12] ='0'; 
	//--- exponent part
		gSciTxBuf[13] ='e'; gSciTxBuf[14] ='+'; gSciTxBuf[15] ='0'; 

		gSciTxBuf[8]  ='1';
		lcd_x_posi=0; lcd_y_posi=2;	
		SendSciString( gSciTxBuf );
		delay_ms(100);	//
		sci_rx_msg_LCD_print_proc();
		delay_ms(100);	//

		gSciTxBuf[8]  ='2';
		sci_rx_msg_start = sci_rx_msg_end = 0;
		lcd_x_posi=0; lcd_y_posi = 3;
		for(clearcnt = 0; clearcnt <40; clearcnt++)
			sci_rx_msg_box[clearcnt] = 0;
		SendSciString( gSciTxBuf ); 
		delay_ms(100);	//
		sci_rx_msg_LCD_print_proc();
		break;
	case BTN_SAVE:
		for( i = 1 ; i< 4; i++ ) clear_line(i);
		lcd_x_posi=0; lcd_y_posi=1;
		CopyCode2TxMsg(SCI_CMD_WRITE_ROM); SendSciString( gSciTxBuf );
/*
		for( i = 0; i< 9;i++)
		{
			Code[i] = '0';
			if(i == 7) Code[i] = '+';
			DisplayChar(CODE_POS[i][0],CODE_POS[i][1],Code[i]);
		}
*/
//		CodeID = 0 ;
		break;
	case BTN_DOWN:
		if(CodeID == 7 ){
			if( Code[CodeID] == '+') Code[CodeID] = '-';
			else                     Code[CodeID] = '+';
		}
		else {
			if      ( Code[CodeID] > '9') Code[CodeID] = '9';
			else if ( Code[CodeID] <= '0') Code[CodeID] = '9';
			else 						  Code[CodeID]--;
		}
		break;

	case BTN_UP :
		if(CodeID == 7 ){
			if( Code[CodeID] == '+') Code[CodeID] = '-'; 
			else					 Code[CodeID] = '+';	 
		}
		else {
			if     ( Code[CodeID] <  '0') 	 	Code[CodeID] = '0';
			else if( Code[CodeID] >= '9') 	 	Code[CodeID] = '0';
			else 								Code[CodeID]++;
		}
		break;
	
	case BTN_RIGHT:		
		if(CodeId == 8) CodeID = 0 ;
		else			CodeID ++ ;	 
		break;

	case BTN_STOP:
		Flag_Btn = 1;
		Flag_Start = 0;
		enter_set_mode();
		break;

	default:
		break;
	}
	if(ChangeCode == 1 )
	{
		ChangeCode = 0;
		DisplayChar(CODE_POS[CodeID][0],CODE_POS[CodeID][1],Code[CodeID]);
		Cursor(CODE_POS[CodeID][0],CODE_POS[CodeID][1],CURSOR_BLINK);				
	}
}

#SEPARATE
void TripCodeDataProc()			// EEPROM TRIP ERROR DATA LOAD
{
	BUTTON KeyIn;

	if(Delay_Timer < 600)
		Delay_Timer++;
	if(Flag_Start == 0)
	{
		Trip_Error = 1;
		Error_x_posi = 0;
		Error_y_posi = 0;
		switch( Flag_Btn )
		{
		case 1:
			strcpy(gSciTxBuf,"9:4:903:0.000e-0");
			break;
		case 2:
			strcpy(gSciTxBuf,"9:4:903:1.000e-0");
			break;
		case 3:
			strcpy(gSciTxBuf,"9:4:903:2.000e-0");
			break;
		case 4:
			strcpy(gSciTxBuf,"9:4:903:3.000e-0");
			break;
		case 5:
			strcpy(gSciTxBuf,"9:4:903:4.000e-0");
			break;
		case 6:
			strcpy(gSciTxBuf,"9:4:903:5.000e-0");
			break;
		case 7:
			strcpy(gSciTxBuf,"9:4:903:6.000e-0");
			break;
		case 8:
			strcpy(gSciTxBuf,"9:4:903:7.000e-0");
			break;
		case 9:
			strcpy(gSciTxBuf,"9:4:903:8.000e-0");
			break;
		case 10:
			strcpy(gSciTxBuf,"9:4:903:9.000e-0");
			break;
		default:
			break;
		}
		Flag_Start = 1;
		lcd_y_posi = 0; lcd_x_posi = 0;
		SendSciString( gSciTxBuf );
		delay_ms(50);
		Delay_Timer = 0;
	}

	if(Delay_Timer >= 600)
	{
		KeyIn = GetKey();

		switch( KeyIn )
		{
		case BTN_STOP:
			Flag_Btn = 1;
			Flag_Start = 0;
			Trip_Error = 3;
			Delay_Timer = 600;
			strcpy(st, "                 ");
			PrintLCD(1,0,st);
			enter_set_mode();
			break;
		case BTN_DOWN:
			Flag_Btn++;
			LCD_Clear();
			Flag_Start = 0;
			break;
		case BTN_UP:
			Flag_Btn--;
			LCD_Clear();
			Flag_Start = 0;
			break;
		default:
			break;
		}
	}

	if(Flag_Btn > 10)
		Flag_Btn = 1;
	else if(Flag_Btn < 1)
		Flag_Btn = 10;
}

#SEPARATE
void ResetCodeDataProc()		// ����Ʈ ����
{
	BUTTON KeyIn;
	char Reset_Cnt;
	
	KeyIn = GetKey();

	if(Flag_Start == 0)
	{
		strcpy(st, " SYSTEM RESET OK?  ");
		PrintLCD(0,0,st);
		strcpy(st, " YES     NO     ");
		PrintLCD(2,3,st);
		Flag_Start = 1;
	}
	switch( KeyIn )
	{
	case BTN_ESC:
		if(Flag_Set == 1)
		DisplayChar(2, Flag_Set + 1, ' ' );
	else if(Flag_Set == 2)
		DisplayChar(2, Flag_Set + 8, ' ' );
		Flag_Set++;
		break;
	case BTN_RIGHT:
		if(Flag_Set == 1)
		DisplayChar(2, Flag_Set + 1, ' ' );
	else if(Flag_Set == 2)
		DisplayChar(2, Flag_Set + 8, ' ' );
		Flag_Set--;
		break;
	case BTN_RUN:
		Flag_Btn = 2;
		Flag_Start = 0;
		enter_monitor_mode();
		if(Flag_Set == 1)
		{
			strcpy(Trip_Message, "                    ");
			strcpy(gSciTxBuf,"9:4:902:5.000e-0");	// RESET
			SendSciString( gSciTxBuf );
			Lcd_Clear();
			for(Reset_Cnt = 0; Reset_Cnt < 10; Reset_Cnt++)
			{
				if(Flag_Start == 1)
				{
					strcpy(st, " - SYSTEM RESET -  ");
					Flag_Start = 0;
				}
				else
				{
					strcpy(st, "                   ");
					Flag_Start = 1;
				}
				delay_ms(200);
				delay_ms(200);
				PrintLCD(1,0,st);
			}
		}
		break;
	case BTN_STOP:
		Flag_Btn = 1;
		Flag_Start = 0;
		enter_set_mode();
		break;
	default:
		break;
	}
	if(Flag_Set > 2)
		Flag_Set = 1;
	else if(Flag_Set < 1)
		Flag_Set = 2;

	if(Flag_Set == 1 && Flag_Start == 1)
		DisplayChar(2, Flag_Set + 1, '*' );
	else if(Flag_Set == 2 && Flag_Start == 1)
		DisplayChar(2, Flag_Set + 8, '*' );
}

#SEPARATE
void SystemInitProc()		// �ý��� �ʱ�ȭ
{
	BUTTON KeyIn;
	
	KeyIn = GetKey();

	if(Flag_Start == 0)
	{
		strcpy(st, " SYSTEM INIT OK?   ");
		PrintLCD(0,0,st);
		strcpy(st, " YES     NO     ");
		PrintLCD(2,3,st);
		Flag_Start = 1;
	}
	switch( KeyIn )
	{
	case BTN_ESC:
		if(Flag_Set == 1 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 1, ' ' );
		else if(Flag_Set == 2 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 8, ' ' );
		if(Flag_Start != 3)
			Flag_Set++;
		break;
	case BTN_RIGHT:
		if(Flag_Set == 1 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 1, ' ' );
		else if(Flag_Set == 2 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 8, ' ' );
		if(Flag_Start != 3)
			Flag_Set--;
		break;
	case BTN_RUN:
		Flag_Btn = 2;
//		enter_monitor_mode();
		if(Flag_Set == 1 && Flag_Start != 3)
		{
			Flag_Start = 3;
			strcpy(Trip_Message, "                    ");
			Lcd_Clear();
			Lcd_x_posi = 0, Lcd_y_posi = 0;
			strcpy(gSciTxBuf,"9:4:902:6.000e-0");	// SYSTEM INIT
			SendSciString( gSciTxBuf );
		}
		break;
	case BTN_STOP:
		Flag_Btn = 1;
		Flag_Start = 0;
		enter_set_mode();
		break;
//	case BTN_UP:
//		Flag_Page++;
//		DisplayChar(0, 0, Flag_Page + '0' );
//		DisplayChar(1, 0, Flag_Page );
//		break;
	default:
		break;
	}
	if(Flag_Set > 2)
		Flag_Set = 1;
	else if(Flag_Set < 1)
		Flag_Set = 2;

	if(Flag_Set == 1 && Flag_Start == 1)
		DisplayChar(2, Flag_Set + 1, '*' );
	else if(Flag_Set == 2 && Flag_Start == 1)
		DisplayChar(2, Flag_Set + 8, '*' );
}

#SEPARATE
void TimeDataSetProc()			// �ð� ����
{
	BUTTON KeyIn;
	char ChangeCode = 0;

	ChangeCode = 1;
	Cursor(2,Time_Count,DISPLAY_CURSE_BLINK_ON);

	if(Flag_Time == 0)
	{
		strcpy(gSciTxBuf,"9:4:906:0.000e-0");
		SendSciString( gSciTxBuf );
		delay_ms(100);
		Flag_Time = 1;
	}
	
	KeyIn = GetKey();

	switch( KeyIn )
	{
	case BTN_ESC:
		Time_Count--;
		if(Time_Count == 4 || Time_Count == 7 || Time_Count == 14 || Time_Count == 17)
			Time_Count--;
		else if(Time_Count == 11)
			Time_Count -= 2;

		if(Time_Count < 2)
			Time_Set_Number = st[19] - '0';
		else
			Time_Set_Number = st[Time_Count] - '0';
		break;
	case BTN_RIGHT:
		Time_Count++;
		if(Time_Count == 4 || Time_Count == 7 || Time_Count == 14 || Time_Count == 17)
			Time_Count++;
		else if(Time_Count == 10)
			Time_Count += 2;

		if(Time_Count > 19)
			Time_Set_Number = st[2] - '0';
		else
			Time_Set_Number = st[Time_Count] - '0';
		break;
	case BTN_UP:
		Time_Set_Number++;
		break;
	case BTN_DOWN:
		Time_Set_Number--;
		break;
	case BTN_STOP:
		lcd_y_posi = 0; lcd_x_posi = 0;
		Flag_Btn = 1;
		Flag_Start = 0;
		Time_Count = 2;
		Time_Set_Number = 0;
		Flag_Time = 0;
		enter_set_mode();
		break;
	case BTN_SAVE:
		Lcd_y_posi = 3, Lcd_x_posi = 0;
		TimeCode[0] = st[2], TimeCode[1] = st[3], TimeCode[2] = st[5];
		TimeCode[3] = st[6], TimeCode[4] = st[8], TimeCode[5] = st[9];
		strcpy(gSciTxBuf,"9:4:904:0.");
		strcpy(&(gSciTxBuf[10]),TimeCode);
		SendSciString( gSciTxBuf );
		delay_ms(150);

		TimeCode[0] = st[12], TimeCode[1] = st[13], TimeCode[2] = st[15];
		TimeCode[3] = st[16], TimeCode[4] = st[18], TimeCode[5] = st[19];
		strcpy(gSciTxBuf,"9:4:904:1.");
		strcpy(&(gSciTxBuf[10]),TimeCode);
		SendSciString( gSciTxBuf );
		sci_rx_msg_start = 0;
		sci_rx_msg_end = 0;
		delay_ms(50);
		Flag_Time = 4;
		break;
	default:
		break;
	}
	if(Time_Count > 19)
		Time_Count = 2;
	else if(Time_Count < 2)
		Time_Count = 19;

	if(Time_Set_Number > 9)
		Time_Set_Number = 0;
	else if(Time_Set_Number < 0)
		Time_Set_Number = 9;

	st[0] = '2';
	st[1] = '0';

	st[Time_Count] = Time_Set_Number + '0';
	
	if(ChangeCode == 1)
	{
		ChangeCode = 0;
		DisplayChar(2,Time_Count,st[Time_Count]);
		Cursor(2,Time_Count,CURSOR_BLINK);
	}
}

#SEPARATE
void ErrorCodeDataProc()		// Trip Error ��� �����
{
	BUTTON KeyIn;
	
	KeyIn = GetKey();

	switch( KeyIn )
	{
	case BTN_STOP:
		Trip_Error = 3;
		enter_monitor_mode();
		break;
	default:
		break;
	}
}

void RecordClearProc()		// Trip Record All Clear
{
	BUTTON KeyIn;
	
	KeyIn = GetKey();

	if(Flag_Start == 0)
	{
		strcpy(st, " REC CLEAR ALL! OK? ");
		PrintLCD(0,0,st);
		strcpy(st, " YES     NO     ");
		PrintLCD(2,3,st);
		Flag_Start = 1;
	}
	switch( KeyIn )
	{
	case BTN_ESC:
		if(Flag_Set == 1)
			DisplayChar(2, Flag_Set + 1, ' ' );
		else if(Flag_Set == 2)
			DisplayChar(2, Flag_Set + 8, ' ' );
		Flag_Set++;
		break;
	case BTN_RIGHT:
		if(Flag_Set == 1)
			DisplayChar(2, Flag_Set + 1, ' ' );
		else if(Flag_Set == 2)
			DisplayChar(2, Flag_Set + 8, ' ' );
		Flag_Set--;
		break;
	case BTN_RUN:
		if(Flag_Set == 1)
		{
			Flag_Btn = 10;
			Lcd_x_posi = 0;
			Lcd_y_posi = 0;
			Lcd_Clear();
			strcpy(Trip_Message, "                    ");
			strcpy(gSciTxBuf,"9:4:904:2.000e-0");
			SendSciString( gSciTxBuf );
			delay_ms(50);
		}
		else
		{
			Flag_Btn = 1;
			Flag_Start = 0;
			enter_set_mode();
		}
		break;
	case BTN_STOP:
		Flag_Btn = 1;
		Flag_Start = 0;
		enter_set_mode();
		break;
	default:
		break;
	}
	if(Flag_Set > 2)
		Flag_Set = 1;
	else if(Flag_Set < 1)
		Flag_Set = 2;

	if(Flag_Btn != 10)
	{
		if(Flag_Set == 1 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 1, '*' );
		else if(Flag_Set == 2 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 8, '*' );
	}
}

void CheckSumErrorProc()
{
	BUTTON KeyIn;
	
	KeyIn = GetKey();

	if(Flag_Start == 0)
	{
		if(Flag_Page == 3)
			strcpy(st, " BACKUP RESTORE OK?");
		else if(Flag_Page == 4)
			strcpy(st, " INIT RESTORE OK?  ");
		PrintLCD(0,0,st);
		strcpy(st, " YES     NO     ");
		PrintLCD(2,3,st);
		Flag_Start = 1;
	}
	switch( KeyIn )
	{
	case BTN_ESC:
		if(Flag_Set == 1 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 1, ' ' );
		else if(Flag_Set == 2 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 8, ' ' );
		if(Flag_Start != 3)
			Flag_Set++;
		break;
	case BTN_RIGHT:
		if(Flag_Set == 1 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 1, ' ' );
		else if(Flag_Set == 2 && Flag_Start == 1)
			DisplayChar(2, Flag_Set + 8, ' ' );
		if(Flag_Start != 3)
			Flag_Set--;
		break;
	case BTN_RUN:
		Flag_Btn = 2;
//		enter_monitor_mode();
		if(Flag_Set == 1 && Flag_Start != 3)
		{
			Flag_Start = 3;
			strcpy(Trip_Message, "                    ");
			Lcd_Clear();
			Lcd_x_posi = 0, Lcd_y_posi = 0;
			if(Flag_Page == 3)
				strcpy(gSciTxBuf,"9:4:907:0.000e-0");
			else if(Flag_Page == 4)
				strcpy(gSciTxBuf,"9:4:907:1.000e-0");
			SendSciString( gSciTxBuf );
		}
		break;
	case BTN_STOP:
		Flag_Btn = 1;
		Flag_Start = 0;
		enter_set_mode();
		break;
	default:
		break;
	}
	if(Flag_Set > 2)
		Flag_Set = 1;
	else if(Flag_Set < 1)
		Flag_Set = 2;

	if(Flag_Set == 1 && Flag_Start == 1)
		DisplayChar(2, Flag_Set + 1, '*' );
	else if(Flag_Set == 2 && Flag_Start == 1)
		DisplayChar(2, Flag_Set + 8, '*' );
}


#SEPARATE
void PositionTestProc()
{/*
	BUTTON KeyIn;
	
	KeyIn = GetKey();

	switch(KeyIn)
	{
	case BTN_RUN:
		Lcd_x_posi = 0;
		Lcd_y_posi = 0;
		strcpy(gSciTxBuf,"9:4:905:9.000e-0");
		SendSciString( gSciTxBuf );
		break;
	case BTN_STOP:
		Lcd_x_posi = 0;
		Lcd_y_posi = 0;
		Flag_Btn = 1;
		Flag_Start = 0;
		enter_set_mode();
		break;
	default:
		break;
	}*/
}
//------------------------------
// End
//------------------------------
