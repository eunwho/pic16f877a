/////////////////////////////////////////////////////////////////////////
//
//	Project Name 	: Input for EW Inverter  
//	Fiele Name	 	: sci.c
//
//  Start 			: 2007.08.01 wednsday
//  Finish			:  
//	Edit 			: 2008.05.21
///////////////////////////////////////////////////////////////////////////
//
// 8Mhz  baud:38400
//

#INT_RDA
void SerialDataReceiveInterrupt( )
{
	static unsigned long msec_count=0;
	static int rxd_count=0;

	if( ulGetDelaymSec( msec_count) > 50 ){ 
		sci_rx_msg_start = sci_rx_msg_end = 0;
	}

	msec_count = ulGetNowCount_msec();	

	sci_rx_msg_end++;	
	if( sci_rx_msg_end >= SCI_RX_MSG_SIZE ) sci_rx_msg_end = 0;
	if( sci_rx_msg_start == sci_rx_msg_end ) sci_rx_msg_start ++; 

	sci_rx_msg_box[sci_rx_msg_end ] = RXREG;

	if( sci_rx_msg_box[sci_rx_msg_end ] < 32
	|| sci_rx_msg_box[sci_rx_msg_end ] > 176){
		sci_rx_msg_box[sci_rx_msg_end ] = ' ';
		sci_rx_msg_end--;
	}

	clear_receive_interrupt_flag();
}

void sci_rx_msg_LCD_print_proc()
{
	char msg;
	char tCnt;

	if( bit_test(RCSTA,1)){ // over_run error
		bit_set(RCSTA,4);
		return;
	}

	if( bit_test(RCSTA,2)){ // framing error
		msg = RXREG; return;
	}
	if(machine_state == STATE_MONITOR_MODE && Flag_Btn == 2)
	{
		strcpy(st, "                    ");
		PrintLCD(1,0,st);
		Flag_Btn = 1;
	}
	if(Trip_error == 3 && machine_state == STATE_MONITOR_MODE)	// �������� ���� TRIP�޽��� ���
	{
		PrintLCD(1,0,Trip_Message);
	//	Trip_error = 0;
	}

	if(sci_rx_msg_box[1] == '-' && sci_rx_msg_box[2] == 'C'
	&& sci_rx_msg_box[3] == 'h')
	{
		Lcd_x_posi = 0, Lcd_y_posi = 0;
	}

	if(sci_rx_msg_box[1] == 'B' && sci_rx_msg_box[2] == 'R'
	&& sci_rx_msg_box[3] == 'E')
	{
		machine_state = CHECKSUM_MODE;
		Flag_Page = 3;
		Lcd_Clear();
		return;
	}
	if(sci_rx_msg_box[1] == 'I' && sci_rx_msg_box[2] == 'R'
	&& sci_rx_msg_box[3] == 'E')
	{
		machine_state = CHECKSUM_MODE;
		Flag_Page = 4;
		Lcd_Clear();
		return;
	}

	// TRIP ERROR ��� �˻�
	if(sci_rx_msg_box[1] == 'T')
	{
		Trip_Header[0] = sci_rx_msg_box[1];
		Trip_Header[1] = sci_rx_msg_box[2];
		Trip_Header[2] = sci_rx_msg_box[3];
	}
	if(Trip_Header[0] == 'T' && Trip_Header[1] == 'R'	// TRIP ERROR ��ȣ�� �� ���
	&& Trip_Header[2] == 'P')
	{
		Trip_Header[0]=' ';								// TRIP ��� �ʱ�ȭ
		Trip_Header[1]=' ';
		Trip_Header[2]=' ';
		lcd_x_posi = 0;
		lcd_y_posi = 0;
		Error_x_posi = 0;
		Error_y_posi = 0;
		Trip_Error = 1;
		machine_state = STATE_ERROR_MODE;				// TRIP ERROR MODE
		strcpy(Trip_Message, "                    ");
		Lcd_Clear();
		return;
	}

	if(Flag_Time == 1)
	{
		for(tCnt = 0; tCnt < 20; tCnt++)
		{
			if(tCnt != 10 && tCnt != 11)
				st[tCnt] = sci_rx_msg_box[tCnt + 1];
		}
		Time_Set_Number = sci_rx_msg_box[3] - '0';

	//	Lcd_Clear();
		PrintLCD(2,0,st);
		Delay_ms(50);
	//	PrintLCD(0,0,sci_rx_msg_box+1);
		Flag_Time = 2;
	//	return;
	}

	while( sci_rx_msg_start != sci_rx_msg_end && Flag_Time != 2)
	{
		sci_rx_msg_start++;
		msg = sci_rx_msg_box[sci_rx_msg_start];
		
		if( sci_rx_msg_start >= SCI_RX_MSG_SIZE ) sci_rx_msg_start = 0;
		
	//	if( msg < 32 ){ nop();}
	//	if( msg <32 || msg > 'z'){nop();}
	//	else if( msg == ':'){ nop();}
	//	else {
			if(Trip_Error == 0 || Trip_Error == 3)
				DisplayChar(lcd_y_posi,lcd_x_posi, msg ); // ���� ���

			if( lcd_x_posi >= 19 ){
				lcd_x_posi = 0; 
				if( lcd_y_posi >= 3)lcd_y_posi = 1;
				else 				lcd_y_posi ++;
			}
			else lcd_x_posi ++;
	//	}
		
		
		if(Trip_Error == 1 && sci_rx_msg_start != 0)			// Trip ���(EEPROM DATA LOAD) , Trip Error ����
		{
			if(msg < 32 ){nop();}
			else if(sci_rx_msg_start >16 && Error_y_posi == 0)	// Error�޽��� 16�� ������ ���
				return;
			else
			{
				if(Error_y_posi == 0)
				{
					if(Error_x_posi > 5 && msg == '2')	
					{
						Error_x_posi = 0;
						Error_y_posi++;
					}
				}
				if(Error_y_posi < 4 && Error_x_posi < 20 && sci_rx_msg_start != 0)
					DisplayChar(Error_y_posi,Error_x_posi, msg );
				if(Error_y_posi == 0 && Error_x_posi > 3
				&& machine_state != STATE_TRIP_MODE)
					Trip_Message[Error_x_posi - 4] = msg;	// TRIP �޽��� ����
						
				if(Error_x_posi >= 19)
				{
					Error_x_posi = 0;
					if( Error_y_posi >= 4)
						Error_y_posi = 0;
					else
						Error_y_posi ++;
				}
				else Error_x_posi++;
			}
		}
	}
}

#SEPARATE
void SerialPortSetup()
{
	//��� ���� �ʱ�ȭ
	TXSTA=0;
	RCSTA=0;	
	
	// port ���� port_C.7=RX --> input, port_C.6=TX --> output
	TRISC=0b10010000;	// debug

	SPBRG = 12;//SPBRG=12;			// 38400
	
	TXSTA=0b00000100;		// TX : disable,8bit data, Asynchronous mode, 16x mode
	// serial_port_enable();
	RCSTA=0b10011000;//RCSTA=0b10010000;		// RX : disable, clear error
	transmit_enable();
}

#SEPARATE
void SendChar(char xmit_data)
{
 	while (!TX_Ready()); 		// wait untill transmit buffer is empty
	TXREG=xmit_data;		// send character
	while (!TX_Ready()); 		// wait untill transmit buffer is empty
}

#SEPARATE
void SendSciString(char *string)
{
	int txdCount =0;

	while((*string)&& (txdCount < 40)){
		SendChar(*(string++));
		txdCount++;
	}	
	while (!TX_Ready());
}

//=========================================
// End of sci.c
//=========================================
